#!/bin/bash

#Adopt Environment Variable
#$1 - NOTEBOOK_DATA_DIR
#$2 - SPARK_EGO_USER
#$3 - SPARK_HOME
#$4 - NOTEBOOK_DATA_BASE_DIR
#$5 - NOTEBOOK_SSL_ENABLED
#$6 - SPARKMS_HOST
#$7 - NOTEBOOK_DEPLOY_DIR
#$8 - <NOT USED>
#$9 - NOTEBOOK_BASE_PORT
#$10 - EGO_MASTER_LIST_PEM
#$11 - EGO_CONTAINER_ID
#$12 - EGOSC_SERVICE_NAME


NOTEBOOK_DATA_DIR=$1
NOTEBOOK_DEPLOY_DIR=$7

source ${NOTEBOOK_DEPLOY_DIR}/scripts/common.inc
source ${NOTEBOOK_DEPLOY_DIR}/scripts/jupyter.inc

NOTEBOOK_PORT_DIR=$1
EGO_CONTAINER_ID=${11}
EGOSC_SERVICE_NAME=${12}
PORT_FILE=${NOTEBOOK_PORT_DIR}/ports
NOTEBOOK_SSL_ENABLED=${5}

if [ -z "${NOTEBOOK_PORT_DIR}" ] || [ -z "${EGO_CONTAINER_ID}" ] || [ -z "${EGOSC_SERVICE_NAME}" ]; then
    echo "One or more input environment variables to readycheck  is undefined." >&2
    exit 1
fi

DOCKER_CONTAINER_NAME="${EGO_CONTAINER_ID}_${EGOSC_SERVICE_NAME}"

#for ipython/jupyter notebook, does not fetch port number from ports file, but fetch it from the auto-produced nbserver json file by jupyter/ipython
grepfile=`find $JUPYTER_DATA_DIR/runtime/ -name nbserver-*.json`
if [ -f "$grepfile" ] ;then
    pidtmp=`cat $grepfile |grep pid |awk -F': ' '{print $2}'`
    pidnum=${pidtmp%,*}
    port2tmp=`cat $grepfile |grep \"port\" |awk -F': ' '{print $2}'`
    port=${port2tmp%,*}
fi

if [[ -z "${port}" || -z "${pidnum}" ]]; then
	#Check if the container is still running
	docker ps | grep $DOCKER_CONTAINER_NAME > /dev/null
	if [ $? -ne 0 ]; then
    	#In this case, the container is not running anymore, which indicates a fatal error has occurred and docker command existed
		#Exit with code 255 to indicate fatal error to docker controller
        echo "Docker container $DOCKER_CONTAINER_NAME has exited." >&2
        exit 255
    fi
fi

if [ -z "${port}" ]; then
    echo "Notebook port is not defined." >&2
    exit 1
fi

if [ -z "${pidnum}" ]; then
    echo "Notebook pid is not defined." >&2
    exit 1
fi

docker exec ${DOCKER_CONTAINER_NAME} netstat -antup | grep ${port} | grep ${pidnum} > /dev/null
if [ $? -eq 0 ] ;then
    host=`hostname -f`
    if [ "$NOTEBOOK_SSL_ENABLED" == true ]; then
        HTTP_PREFIX="https"
    else
        HTTP_PREFIX="http"
    fi
    printf "${HTTP_PREFIX}://${host}:${port}"
    exit 0
else
	#Check if the container is still running
	docker ps | grep $DOCKER_CONTAINER_NAME > /dev/null
	if [ $? -ne 0 ]; then
    	#In this case, the container is not running anymore, which indicates a fatal error has occurred and docker command existed
		#Exit with code 255 to indicate fatal error to docker controller
        echo "Docker container $DOCKER_CONTAINER_NAME has exited." >&2
        exit 255
	else
    	echo "Notebook process has not started." >&2
    	exit 1
    fi
fi