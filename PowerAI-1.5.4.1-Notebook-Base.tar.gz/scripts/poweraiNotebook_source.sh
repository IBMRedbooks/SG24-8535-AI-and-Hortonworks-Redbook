#!/bin/bash


### This script sets up the PATH env var to point to /opt/anaconda2 and  source all of the powerai
###  frameworks

source /opt/DL/tensorflow/bin/tensorflow-activate
source /opt/DL/tensorboard/bin/tensorboard-activate


source /opt/DL/caffe/bin/caffe-activate
source /opt/DL/ddl/bin/ddl-activate
source /opt/DL/openblas/bin/openblas-activate
source /opt/DL/bazel/bin/bazel-activate


