#!/bin/bash

source ${NOTEBOOK_DEPLOY_DIR}/scripts/common.inc
source ${NOTEBOOK_DEPLOY_DIR}/scripts/jupyter.inc


: 'Exit codes:
	1 - Failed to create directory
	2 - Spark master URL not found
	3 - Failed to authenticate
	4 - Error decrypting password
	5 - Open SSL error
	6 - Failed to retrieve SSL information
	7 - ASCD_REST_CACERT_PATH not defined
	8 - ASCD_REST_CACERT_PATH does not exist
	9 - Directory is not defined
	10 - Directory already exists
	11 - Failed to write to base data dir
	
	RESERVED ERROR CODES - Will cause service to block
	17 - Failed to start command (EGO code)
	25 - Failed to create stdout/stderr redirection files (EGO code)
	99 - Local timestamp does not match service timestamp
'

#######################
### Utility Methods ###
#######################
make_directory_with_multilevel_permission() {
    # $1 Directory path
    # $2 Optional destination directory permissions
    # $3 Optional intermediate directory permissions (multilevel directory)
    local path="$1"
    local destperm="$2"
    local interperm="$3"

    if [ -z "$path" ]; then
        echo_log "Directory is not defined"
        exit 9
    fi

    if [ -d "$path" ]; then
        echo_log "$path already exists"
        exit 10
    fi
    
    #remove extra slashes in the path
    path=$(sed 's/\/\+/\//g'<<<"$path")
    
    IFS=/
    array=($path)
    unset IFS
    partialpath=""

    for dir in "${array[@]}"; do
        if [ -n "$dir" ]; then
            partialpath="${partialpath}/${dir}"
            if [ ! -d "$partialpath" ]; then
                mkdir "$partialpath"
                local rc="$?"
                if [ "$rc" -ne 0 ]; then
                    echo_log "Error when trying to create directory $path. Exit code: $rc"
                    exit 1
                fi
                if [ "${partialpath%/}" == "${path%/}" ]; then
                    :
                else
                    chmod $interperm "$partialpath"
                fi
            fi
        fi
    done
}


#allow non-root user to launch a jupyter notebook
unset XDG_RUNTIME_DIR
#Create base data directory if it does not already exist
#Ensure user has permission to write to the directory
if [ ! -d "$NOTEBOOK_DATA_DIR" ]; then
    make_directory_with_multilevel_permission ${NOTEBOOK_DATA_DIR} 755 755
fi

if [ ! -d "$LOGDIR" ]; then
    make_directory_with_multilevel_permission $LOGDIR 755 755
fi
#restore the history log file with timestamp
if [ -f $LOGFILE ]; then
    mv $LOGFILE $LOGDIR/ipython_`date +%Y%m%d_%H%M`.log
fi


touch $LOGFILE
echo_log "Logging to $LOGFILE"
echo_log_to_file "Entered" $LOGFILE

#Check timestamp first to ensure notebook deployment is up to date
validate_timestamp

rm -rf ${PORT_FILE}
rc="$?"
if [ "$rc" -ne 0 ]; then
    echo_log "The user `whoami` does not have write access to existing files in the notebook base data directory $NOTEBOOK_DATA_DIR. If the notebook's consumer was modified, contact your cluster administrator to grant ownership of this notebook's data to the new consumer execution user or to correct the consumer in the Spark instance group configuration."
    exit 11
fi
touch ${PORT_FILE}

#Handle extra conf if specified
source "${SPARK_HOME}"/conf/spark-env.sh

if [ -n "$SPARK_EGO_CONF_DIR_EXTRA" ]; then
    if [ -f "${SPARK_EGO_CONF_DIR_EXTRA}/spark-env.sh" ]; then
      source "${SPARK_EGO_CONF_DIR_EXTRA}"/spark-env.sh
    fi
else
	echo_log_to_file "no extra configuration defined" $LOGFILE
fi

if [ -n "$NOTEBOOK_EXTRA_CONF_FILE" ]; then
        if [ -e $NOTEBOOK_EXTRA_CONF_FILE ]; then
                source $NOTEBOOK_EXTRA_CONF_FILE
        else
            echo_log_to_file "Extra configuration file $NOTEBOOK_EXTRA_CONF_FILE does not exist. Starting notebook with default configurations" $LOGFILE
        fi
fi

if [ -n "$PYSPARK_PYTHON" ]; then
	echo_log_to_file "customerized PYTHONPATH defined" $LOGFILE
    export PYSPARK_PYTHON=$PYSPARK_PYTHON
else
    export PYSPARK_PYTHON=$NOTEBOOK_DEPLOY_DIR/install/bin/python
	echo_log_to_file "no customerized PYTHONPATH defined" $LOGFILE
fi

export PYSPARK_DRIVER_PYTHON=$NOTEBOOK_DEPLOY_DIR/install/bin/jupyter

export IPYTHONDIR=$DATADIR/ipydir
export JUPYTER_CONFIG_DIR=$NOTEBOOK_DATA_DIR/config
export JUPYTER_NOTEBOOK_DIR=$NOTEBOOK_DATA_DIR/notebooks

#when restart service, update all the config files
if [ -d "$JUPYTER_DATA_DIR" ]; then
    rm -rf $JUPYTER_DATA_DIR
fi

if [ -d "$JUPYTER_CONFIG_DIR" ]; then
    rm -rf $JUPYTER_CONFIG_DIR
fi

if [ -d "$IPYTHONDIR" ]; then
    rm -rf $IPYTHONDIR
fi

if [ ! -d "$JUPYTER_CONFIG_DIR" ]; then
    make_directory_with_multilevel_permission $JUPYTER_CONFIG_DIR 755 755
fi
cp ./scripts/jupyter_notebook_config.py $JUPYTER_CONFIG_DIR
if [ ! -d "$JUPYTER_CONFIG_DIR/custom" ]; then
    make_directory_with_multilevel_permission $JUPYTER_CONFIG_DIR/custom 755 755
fi
cp ./scripts/custom.js $JUPYTER_CONFIG_DIR/custom/
if [ ! -d "$JUPYTER_DATA_DIR" ]; then
    make_directory_with_multilevel_permission $JUPYTER_DATA_DIR 755 755
fi
if [ ! -d "$IPYTHONDIR/profile_default/startup" ]; then
    make_directory_with_multilevel_permission $IPYTHONDIR/profile_default/startup 755 755
fi
cp ./scripts/00-pyspark-setup.py $IPYTHONDIR/profile_default/startup/
cp ./scripts/01-defaultfs-setup.py $IPYTHONDIR/profile_default/startup/
if [ ! -d "$JUPYTER_NOTEBOOK_DIR" ]; then
    make_directory_with_multilevel_permission $JUPYTER_NOTEBOOK_DIR 755 755
fi

IPYTHON_LIB_PATH=`find $NOTEBOOK_DEPLOY_DIR/install/lib -name "*site-package*"`

export PYTHONPATH="$IPYTHON_LIB_PATH: ${PYTHONPATH}"

cd $JUPYTER_CONFIG_DIR

CONFIG_FILE=jupyter_notebook_config.py

sed -i "s,# c.NotebookApp.ip =.*$,c.NotebookApp.ip = '*',g" $CONFIG_FILE
sed -i "s,c.NotebookApp.ip =.*$,c.NotebookApp.ip = '*',g" $CONFIG_FILE
sed -i "s,# c.NotebookApp.open_browser =.*$,c.NotebookApp.open_browser = False,g" $CONFIG_FILE
sed -i "s,c.NotebookApp.open_browser =.*$,c.NotebookApp.open_browser = False,g" $CONFIG_FILE
sed -i "s,# c.NotebookApp.port_retries =.*$,c.NotebookApp.port_retries = 1000,g" $CONFIG_FILE
sed -i "s,c.NotebookApp.port_retries =.*$,c.NotebookApp.port_retries = 1000,g" $CONFIG_FILE
sed -i "s,# c.NotebookApp.login_handler_class =.*$,c.NotebookApp.login_handler_class = 'notebook.auth.loginegoauth.EgoLoginHandler',g" $CONFIG_FILE
sed -i "s,c.NotebookApp.login_handler_class =.*$,c.NotebookApp.login_handler_class = 'notebook.auth.loginegoauth.EgoLoginHandler',g" $CONFIG_FILE

echo_log_to_file "export SPARK_HOME=$SPARK_HOME" $LOGFILE
export SPARK_HOME=$SPARK_HOME
one_notebook_master_url="one_notebook_master_url"
activedataconnectors="activedataconnectors"
defaultfsdataconnector="defaultfsdataconnector"
notebookcookieprefix="cookie_notebook"
notebookcookieegoprefix="cookie_notebook_ego"

#MASTER
if [ -n "$CONDUCTOR_REST_URL" ]; then
    last_char=${CONDUCTOR_REST_URL: -1}
    if [ "${last_char}" != "/" ]; then
       CONDUCTOR_REST_URL=${CONDUCTOR_REST_URL}"/"
    fi
    
    if [[ "$CONDUCTOR_REST_URL" == https://* ]]; then
    	#ASCD is SSL enabled - Need to user the cacert for REST calls to ASCD
		if [ -z "$ASCD_REST_CACERT_PATH" ]; then
			echo_log_to_file "The ASCD_REST_CACERT_PATH is not defined. This value is required to connect to ascd REST service using https." $LOGFILE
			exit 7
		else
			#First resolve any environment variables in the path
			ASCD_REST_CACERT_PATH=`eval echo $ASCD_REST_CACERT_PATH`
			if [ ! -f $ASCD_REST_CACERT_PATH ]; then
				echo_log_to_file "The CA Certificate $ASCD_REST_CACERT_PATH does not exist. This file is required to connect to ascd REST service using https." $LOGFILE
				exit 8
			fi
			
			curlSecureOpt="--cacert $ASCD_REST_CACERT_PATH"
		fi
	else
		curlSecureOpt="-k"
	fi
fi

#For Dockerized case - determine SERVICE_ascd_LOCATION value by cycling through hosts in EGO_MASTER_LIST_PEM
if [ "$SERVICE_ascd_LOCATION" == "\${SERVICE_ascd_LOCATION}" -o ! -n "$SERVICE_ascd_LOCATION" ]; then
	if [ -n "${EGO_MASTER_LIST_PEM}" ]; then
    	egoMasterListPem=$(echo $EGO_MASTER_LIST_PEM | tr "," "\n")
        for SERVICE_ascd_LOCATION in $egoMasterListPem; do
        	tmpConductorRestUrl=${CONDUCTOR_REST_URL//\$\{SERVICE_ascd_LOCATION\}/$SERVICE_ascd_LOCATION}
            testOutput=`curl $curlSecureOpt -XGET ${tmpConductorRestUrl}conductor/instances`
            if [ $? -eq 0 ]; then
            	CONDUCTOR_REST_URL=$tmpConductorRestUrl
                break
            fi
        done
	fi
fi

export MANAGEMENT_HOST_LIST=$SERVICE_ascd_LOCATION

do_logon() {
    COUNTER=0
    SLEEP_INTERVAL=3
    while [ true ]; do
        csrfStr=`curl $curlSecureOpt -c ${DATADIR}/$2.$$ -XGET -H'Accept: application/json' -H"Authorization: PlatformToken token=$EGO_SERVICE_CREDENTIAL" $1 ${tlsVersion}`
        
        #If the REST service isn't up yet, nothing will come back in the csrfStr, continue looping until REST service is up
        if [ -z "$csrfStr" ]; then
        	COUNTER=$(($COUNTER + 1 ))
        	#Log a message every 30 seconds to help debugability in the event that REST service is not available
			if [ $(( $COUNTER % 10 )) -eq 0 ]; then
				echo_log_to_file "Unable to connect to the ascd REST service $1 after $(($COUNTER*$SLEEP_INTERVAL)) seconds." $LOGFILE
			fi
			sleep $SLEEP_INTERVAL
            continue
        fi
        
        #If csrfStr has content it means the call connected and returned something, try to parse it for the real token {"csrftoken":"...."}
        csrfArr=($(echo $csrfStr | sed "s/[{}:]/ /g"))
        arrLen=${#csrfArr[@]}
        csrfToken=`echo ${csrfArr[1]} | sed "s/\"//g"`
        if [ -z $csrfToken ] || [ "${arrLen}" != "2" ]; then
        	if [ -n "$csrfStr" ]; then
        		echo_log_to_file "$csrfStr" $LOGFILE $LOGFILE
        	fi
            echo_log_to_file "$1 failed." $LOGFILE
    		exit 3
        else
            echo_log_to_file "csrfStrToken got successfully" $LOGFILE
            break
        fi
    done
}

if [ -n "$CONDUCTOR_REST_URL" ]; then

    curlflag=`curl --help |grep tlsv1.2`
    if [ -n "$curlflag" ]; then
    	tlsVersion="--tlsv1.2"
    else
    	tlsVersion="--tlsv1"
    fi
    
    #Get a list of management hosts
    if [ -n "$EGO_REST_URL" ]; then
	    
        last_char=${EGO_REST_URL: -1}
        if [ "${last_char}" != "/" ]; then
            EGO_REST_URL=${EGO_REST_URL}"/"
        fi
    
        tmpEgoRestUrl=${EGO_REST_URL//\$\{SERVICE_REST_LOCATION\}/$SERVICE_REST_LOCATION}
        
        do_logon "${tmpEgoRestUrl}ego/v1/auth/logon" ${notebookcookieegoprefix}
        
        mgmtHostList=""
        testOutput=`curl $curlSecureOpt -s -b ${DATADIR}/${notebookcookieegoprefix}.$$ -H'Accept:application/json' -H"Authorization: PlatformToken token=$EGO_SERVICE_CREDENTIAL" -X GET "${tmpEgoRestUrl}ego/v1/resourcegroups/ManagementHosts/members" ${tlsVersion}`
        if [ $? -eq 0 ]; then
    	    memberArr=($(echo $testOutput | sed "s/[][{}]//g" | awk -v k="text" '{n=split($0,a,","); for (i=1; i<=n; i++) print a[i]}'))
            arrLen=${#memberArr[@]}
            for i in "${memberArr[@]}"
            do
                itemArr=($(echo ${i} | sed "s/[\"]//g" | sed "s/[:]/ /g"))
                if [ "${itemArr[0]}" == "hostname" ]; then
                    if [ "${mgmtHostList}" != "" ]; then
                        mgmtHostList="${mgmtHostList},${itemArr[1]}"
                    else
                        mgmtHostList="${itemArr[1]}"
                    fi
                fi
            done
        fi
        if [ "${mgmtHostList}" != "" ]; then
            export MANAGEMENT_HOST_LIST=${mgmtHostList}
        fi
    fi
    
    do_logon "${CONDUCTOR_REST_URL}conductor/v1/auth/logon" ${notebookcookieprefix}

    retrialcount=0
    while [ $retrialcount -le 60 ]
    do
       output=`curl $curlSecureOpt -s -b ${DATADIR}/${notebookcookieprefix}.$$ -H'Accept:application/json' -X GET "${CONDUCTOR_REST_URL}conductor/v1/instances?id=${SPARK_INSTANCE_GROUP_UUID}&fields=outputs,connectors" ${tlsVersion}`
       # Parse out the master URL from the one_notebook_master_url output
       echo "${output}" |grep -qF "$one_notebook_master_url"
       if [ $? -ne 0 ]; then
           echo_log_to_file "The Spark notebook master URL was not found. Either the assigned user ${SPARK_EGO_USER} has no permission to access this Spark Instance Group, or the notebook master service is not started." $LOGFILE
           echo_log_to_file ${output} $LOGFILE
           exit 2
       fi
       masterurl=`echo ${output} | awk '{n=split($0,a,","); for (i=1; i<=n; i++) { if (a[i] ~ /one_notebook_master_url/) print a[i+1] }}' | awk '{n=split($0,a,":\""); print a[2]}' | tr "\"}" " "`
       masterurl=`echo $masterurl | xargs`
       numcolon=`echo "${masterurl}" | awk -F':' '{print NF-1}'`
       if [ "${numcolon}" == "2" ]; then
            break
       fi
       sleep 3
       retrialcount=$(($retrialcount + 1 ))
    done

    # exit after max retrial to retrieve masterurl
    if [ $retrialcount -ge 61 ]; then
		echo_log_to_file "Notebook master url is not fetched successfully, please try restart notebook service or check if the notebook master service is alive" $LOGFILE
		exit 2
    fi
    
    # check SSL is enabled 
    if [ "${NOTEBOOK_SSL_ENABLED}" == "true" ]; then
        TIER=tier3
      	sslBody=`curl $curlSecureOpt -s -b ${DATADIR}/${notebookcookieprefix}.$$ -H'Accept:application/json' -X GET "${CONDUCTOR_REST_URL}conductor/v1/instances/${SPARK_INSTANCE_GROUP_UUID}/sslconf/${TIER}" ${tlsVersion}`
        sslCertPath=`echo ${sslBody} | awk '{n=split($0,a,","); for (i=1; i<=n; i++) { print a[i] }}' | awk '{n=split($0,a,":\""); if ($0 ~ /tier3opensslcertpath/) print a[2]}' | tr "\"" " "`
        sslKeyPath=`echo ${sslBody} | awk '{n=split($0,a,","); for (i=1; i<=n; i++) { print a[i] }}' | awk '{n=split($0,a,":\""); if ($0 ~ /tier3opensslkeypath/) print a[2]}' | tr "\"" " "`
        sslPemPasswd=`echo ${sslBody} | awk '{n=split($0,a,","); for (i=1; i<=n; i++) { print a[i] }}' | awk '{n=split($0,a,":\""); if ($0 ~ /tier3opensslpempassword/) print a[2]}' | tr "\"" " "`
           
        if [ -n "${sslCertPath}" ] && [ -n "${sslKeyPath}" ] && [ -n "${sslPemPasswd}" ]; then
        	#Expand the sslCertPath and sslKeyPath in case they have reference to any environment variables
            sslCertPath=`eval echo $sslCertPath`
            sslKeyPath=`eval echo $sslKeyPath`
       		ascdConfBody=`curl $curlSecureOpt -s -b ${DATADIR}/${notebookcookieprefix}.$$ -H'Accept:application/json' -X GET "${CONDUCTOR_REST_URL}conductor/v1/ascdconf?key=ASC_VERSION" ${tlsVersion}`
        	ascdVersion=`echo $ascdConfBody | awk '{n=split($0,a,":\""); if ($0 ~ /ASC_VERSION/) print a[2]}' | tr -d "\"" | tr -d "}"`
        		
        	if [ -n "${ascdVersion}" ]; then
        		rm -rf ${DATADIR}/${notebookcookieprefix}.$$
     	    fi
    	else 
    	    #REST API call must have failed - log the response body
    	    echo_log_to_file "$sslBody" $LOGFILE
        fi

        # exit after max retrial to retrieve SSL and ASCD_VERSION
    	if [ -z "${sslCertPath}" ] || [ -z "${sslKeyPath}" ] || [ -z "${sslPemPasswd}" ] || [ -z "${ascdVersion}" ]; then
        	echo_log_to_file "Notebook SSL information is not fetched successfully, please try to restart notebook service or check if the SSL is configured properly" $LOGFILE
        	exit 6
    	fi
		
        DECRYPT_UTILITY=${EGO_TOP}/conductorspark/${ascdVersion}/bin/aes-decrypt.sh
        TIER3_TMP_KEY_PATH=${DATADIR}/tier3Keyfile.key
        PEM_PHRASE=${DATADIR}/tmpfile
        
        #Create tmpfile
        if [ -f "${PEM_PHRASE}" ]; then
            rm -rf "${PEM_PHRASE}"
        fi
        
        touch "${PEM_PHRASE}"
        chmod 600 "${PEM_PHRASE}"
        
        #Decrypt AES PEM Passwd
        ${DECRYPT_UTILITY} ${sslPemPasswd} > ${PEM_PHRASE}
        if [ $? -ne 0 ]; then
            echo_log_to_file "An error has occurred when decrypting PEM Passphrase. Exit code $?" $LOGFILE
            exit 4
        fi
        
        #Strip PEM passphrase
        openssl rsa -in ${sslKeyPath} -out ${TIER3_TMP_KEY_PATH} -passin file:${PEM_PHRASE}
        if [ $? -ne 0 ]; then
            echo_log_to_file "An error occurred with OpenSSL. Exit code $?" $LOGFILE
            exit 5
        fi
        
        #Cleanup tmpfile
        if [ -f "${PEM_PHRASE}" ]; then
            rm -rf "${PEM_PHRASE}"
        fi
    else
        rm -rf ${DATADIR}/${notebookcookieprefix}.$$
    fi
else
    masterurl=spark://$SPARKMS_HOST:$SPARK_MASTER_PORT
fi
echo_log_to_file "Master URL is $masterurl" $LOGFILE

#Parse out the data connector information
echo "${output}" |grep -qF "$activedataconnectors"
if [ $? -eq 0 ]; then
	activeDataconnectorsParam=`echo ${output} | awk '{n=split($0,a,":"); for (i=1; i<=n; i++) { if (a[i] ~ /activedataconnectors/) print a[i+1] }}'`
	#Parse out the contents between the [ ]
	activeDataconnectorsList=${activeDataconnectorsParam##[}
	activeDataconnectorsList=${activeDataconnectorsList%%]*}
	#Remove quotations from each data connector name in the array
	activeDataconnectorsList=`echo ${activeDataconnectorsList} | sed 's/\"//g'`
	echo_log_to_file "Active data connectors = $activeDataconnectorsList" $LOGFILE
fi

echo "${output}" |grep -qF "$defaultfsdataconnector"
if [ $? -eq 0 ]; then
	defaultFsDc=`echo ${output} | awk '{n=split($0,a,","); for (i=1; i<=n; i++) { if (a[i] ~ /defaultfsdataconnector/) print a[i] }}' | awk '{n=split($0,a,":\""); print a[2]}' | tr "\"}]" " "`
	defaultFsDc=`echo "$defaultFsDc" | tr -d '[:space:]'`
	echo_log_to_file "Data connector to use for fs.defaultFS = $defaultFsDc" $LOGFILE
fi

#Build up the PYSPARK_SUBMIT_ARGS and then export
pySparkSubmitArgs="--deploy-mode client --master $masterurl"
if [ -n "$EGO_SERVICE_CREDENTIAL" ] && [ "$EGO_SERVICE_CREDENTIAL" == "${EGO_SERVICE_CREDENTIAL// /}" ]; then
    egoCred=$EGO_SERVICE_CREDENTIAL
    egoCred=${egoCred//\"/\\\"}
    pySparkSubmitArgs="$pySparkSubmitArgs --conf spark.ego.credential=$egoCred"
fi
if [ -n "$activeDataconnectorsList" ]; then
	pySparkSubmitArgs="$pySparkSubmitArgs --conf spark.ego.dataconnectors=$activeDataconnectorsList"
fi

pySparkSubmitArgs="$pySparkSubmitArgs pyspark-shell"
export PYSPARK_SUBMIT_ARGS="$pySparkSubmitArgs"


#If default fs data connector is defined, we need to define CORE_SITE_DEFAULTFS_XML_FILENAME environment variables
#The hadoop configuration will be applied by the 01-defaultfs-setup.py script after SparkContext is initialized by 00-pyspark-setup.py
if [ -n "$defaultFsDc" ]; then
	coreSiteFilename="$defaultFsDc""_core-site_defaultfs.xml"
	if [ -n "$coreSiteFilename" ]; then
		#Set the filename in CORE_SITE_DEFAULTFS_XML_FILENAME
		export CORE_SITE_DEFAULTFS_XML_FILENAME=$coreSiteFilename
	else
		echo_log_to_file "Could not find the $coreSiteFilename file. No default data connector will be used." $LOGFILE
	fi
fi

cd $JUPYTER_NOTEBOOK_DIR

## source cuda, use  proxy
[ -e /etc/profile.d/cuda.sh ] && source /etc/profile.d/cuda.sh
#[ -e /etc/profile.d/proxy.sh ] && source /etc/profile.d/proxy.sh
## can't have proxy set up otherwise  users can't log onto the jupyter  notebook
## users wishing to download things from the  internet will need to set up proxy themselves

PATH=`echo $PATH`
export PATH=${NOTEBOOK_DEPLOY_DIR}/install/bin:$PATH
echo "path=$PATH" > /tmp/jupyter.log

OLD_PYTHONPATH=`echo $PYTHONPATH`
export PYTHONPATH=""

source /opt/DL/tensorflow/bin/tensorflow-activate
source /opt/DL/tensorboard/bin/tensorboard-activate
source /opt/DL/caffe/bin/caffe-activate
source /opt/DL/ddl/bin/ddl-activate
source /opt/DL/openblas/bin/openblas-activate
source /opt/DL/bazel/bin/bazel-activate
source /opt/DL/pytorch/bin/pytorch-activate
source /opt/DL/snap-ml-spark/bin/snap-ml-spark-activate
source /opt/DL/snap-ml-mpi/bin/snap-ml-mpi-activate
source /opt/DL/snap-ml-local/bin/snap-ml-local-activate


## need this hack otherwise tensorflow protobuf is not used and PowerAI frameworks break. Sigh!
export PYTHONPATH=$PYTHONPATH:$OLD_PYTHONPATH
echo "PYTHONPATH=$PYTHONPATH" >> /tmp/jupyter.log


PATH=`echo $PATH`
echo "new path=$PATH" >> /tmp/jupyter.log


INSTALLED_VERSION=`$NOTEBOOK_DEPLOY_DIR/install/bin/jupyter notebook --version`
if is_version_equal_or_greater "${INSTALLED_VERSION}" "5.0.0"; then
    $NOTEBOOK_DEPLOY_DIR/install/bin/jupyter notebook --allow-root --certfile=${sslCertPath} --keyfile=${TIER3_TMP_KEY_PATH} --notebook-dir=$JUPYTER_NOTEBOOK_DIR >> $LOGFILE 2>&1
else
    $NOTEBOOK_DEPLOY_DIR/install/bin/jupyter notebook --certfile=${sslCertPath} --keyfile=${TIER3_TMP_KEY_PATH} --notebook-dir=$JUPYTER_NOTEBOOK_DIR >> $LOGFILE 2>&1
fi

if [ $? -eq 0 ] ;then
    # Keep the activity working
    while [ true ]; do sleep 10; done
else
    exit
fi
