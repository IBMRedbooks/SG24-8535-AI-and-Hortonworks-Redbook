#!/bin/bash

source ./scripts/common.inc
source ./scripts/jupyter.inc

sleep 10

while [ 1 ]
do
        retrialtime=0
        while [ $retrialtime -le 29 ]
        do
            sleep 10
            retrialtime=$(($retrialtime + 1))
            IPID=`ps -ef|grep "${DATADIR}"/notebooks |grep -v grep |awk '{print $2}'`
            if [ -n "$IPID" ]; then
               port1=`netstat -lnp 2> /dev/null|grep "${IPID}"/python |grep -v tcp6|awk '{split($4,a,":"); print a[2]}'`
               # runtime directory does not get created immediately, check directory exist before grep
               if [ ! -d "$JUPYTER_DATA_DIR/runtime/" ]; then
                   continue
               fi
               break
            fi
        done
        if [ $retrialtime -eq 30 ]; then
            echo_log_to_file "Unable to find URL for the Jupyter notebook service." $LOGFILE
            echo "UPDATE_STATE 'ERROR'"
            echo "END"
            exit 0
        fi
        grepfile=`find $JUPYTER_DATA_DIR/runtime/ -name nbserver-*.json`
        port2tmp=`cat $grepfile |grep \"port\" |awk -F': ' '{print $2}'`
        port2=${port2tmp%,*}
		if [ -n "$port1" ] && [ "$port1" == "$port2" ]; then
           if [ "$NOTEBOOK_SSL_ENABLED" == true ]; then
               HTTP_PREFIX="https"
           else
               HTTP_PREFIX="http"
           fi
           URL=${HTTP_PREFIX}://$EGOSC_INSTANCE_HOST:$port1
           echo_log_to_file "Jupyter notebook service is running on $URL" $LOGFILE
           echo $port1 >> $PORT_FILE
           echo "UPDATE_INFO '$URL'"
           echo "UPDATE_STATE 'READY'"
           echo "END"
           exit 0
        fi
done
